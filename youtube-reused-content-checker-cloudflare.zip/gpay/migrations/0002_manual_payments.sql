-- Manual GPay payments. Status is independent of scan status.
-- awaiting_payment -> pending_verification -> approved | rejected
CREATE TABLE IF NOT EXISTS manual_payments (
  id            TEXT PRIMARY KEY,               -- random UUID
  token_hash    TEXT NOT NULL,                  -- SHA-256 of the buyer's access token
  scan_ref      TEXT NOT NULL,                  -- your existing scan/job id (or channel id)
  amount_inr    INTEGER NOT NULL DEFAULT 49,
  status        TEXT NOT NULL DEFAULT 'awaiting_payment'
                CHECK (status IN ('awaiting_payment','pending_verification','approved','rejected')),
  utr           TEXT,
  utr_attempts  INTEGER NOT NULL DEFAULT 0,
  reject_reason TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  submitted_at  TEXT,
  reviewed_at   TEXT
);

-- A UTR can back only one payment.
CREATE UNIQUE INDEX IF NOT EXISTS idx_manual_payments_utr
  ON manual_payments(utr) WHERE utr IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_manual_payments_status ON manual_payments(status);

-- Audit trail of every admin decision.
CREATE TABLE IF NOT EXISTS payment_audit (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id TEXT NOT NULL,
  action     TEXT NOT NULL,
  note       TEXT,
  at         TEXT NOT NULL DEFAULT (datetime('now'))
);
