import { Env, isAdmin, json, readJson } from "../../_lib/payments";

// GET  /api/admin/payments?status=pending_verification
// POST /api/admin/payments { id, action: "approve" | "reject", reason? }
// Both require Authorization: Bearer <ADMIN_TOKEN>.

export const onRequestGet: PagesFunction<Env> = async ({ request, env }) => {
  if (!isAdmin(request, env)) return json({ error: "Unauthorized" }, 401);
  const status = new URL(request.url).searchParams.get("status") ?? "pending_verification";
  const { results } = await env.DB.prepare(
    `SELECT id, scan_ref, amount_inr, status, utr, created_at, submitted_at, reviewed_at, reject_reason
     FROM manual_payments WHERE status = ? ORDER BY COALESCE(submitted_at, created_at) DESC LIMIT 200`
  ).bind(status).all();
  return json({ payments: results });
};

export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  if (!isAdmin(request, env)) return json({ error: "Unauthorized" }, 401);
  const b = await readJson<{ id: string; action: string; reason: string }>(request);
  if (!b.id || (b.action !== "approve" && b.action !== "reject")) return json({ error: "Invalid request" }, 400);

  const next = b.action === "approve" ? "approved" : "rejected";
  const reason = b.action === "reject" ? (b.reason ?? "").slice(0, 300) || "Payment could not be matched" : null;

  // Only a payment waiting for verification can be decided.
  const res = await env.DB.prepare(
    `UPDATE manual_payments SET status = ?, reject_reason = ?, reviewed_at = datetime('now')
     WHERE id = ? AND status = 'pending_verification'`
  ).bind(next, reason, b.id).run();
  if (!res.meta.changes) return json({ error: "Payment is not pending verification" }, 409);

  await env.DB.prepare("INSERT INTO payment_audit (payment_id, action, note) VALUES (?, ?, ?)")
    .bind(b.id, next, reason).run();
  return json({ ok: true, status: next });
};
