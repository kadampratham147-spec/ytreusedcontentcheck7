import { Env, assertPaymentApproved, json, readJson } from "../../_lib/payments";

// POST /api/scan/start { paymentId, scanRef }
// The payment gate is real. The scan itself is NOT implemented in this starter.
export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  const b = await readJson<{ paymentId: string; scanRef: string }>(request);
  try {
    await assertPaymentApproved(env, b.paymentId ?? "", b.scanRef ?? "");
  } catch (res) {
    if (res instanceof Response) return res;
    throw res;
  }
  // TODO: create/queue your scan job here (existing scan engine).
  return json({ message: "Payment verified. Connect your scan engine in functions/api/scan/start.ts." }, 501);
};
