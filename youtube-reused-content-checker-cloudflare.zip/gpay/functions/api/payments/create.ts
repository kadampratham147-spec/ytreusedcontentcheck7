import { Env, PRICE_INR, json, readJson, sha256 } from "../../_lib/payments";

// POST /api/payments/create  { scanRef: string }
// Call only after channel validation has passed. Returns the payment id + buyer token.
export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  const body = await readJson<{ scanRef: string }>(request);
  const scanRef = (body.scanRef ?? "").trim();
  if (!scanRef || scanRef.length > 128) return json({ error: "Invalid scan reference" }, 400);

  const id = crypto.randomUUID();
  const token = crypto.randomUUID() + crypto.randomUUID();
  await env.DB.prepare(
    "INSERT INTO manual_payments (id, token_hash, scan_ref, amount_inr) VALUES (?, ?, ?, ?)"
  ).bind(id, await sha256(token), scanRef, PRICE_INR).run();

  return json({ paymentId: id, token, amount: PRICE_INR, status: "awaiting_payment" }, 201);
};
