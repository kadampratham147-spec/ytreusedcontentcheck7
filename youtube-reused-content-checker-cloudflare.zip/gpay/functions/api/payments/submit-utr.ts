import { Env, json, readJson, sha256 } from "../../_lib/payments";

// POST /api/payments/submit-utr { paymentId, token, utr }
// Moves the payment to pending_verification. This is NOT proof of payment.
export const onRequestPost: PagesFunction<Env> = async ({ request, env }) => {
  const b = await readJson<{ paymentId: string; token: string; utr: string }>(request);
  const utr = (b.utr ?? "").replace(/\s+/g, "");
  if (!b.paymentId || !b.token) return json({ error: "Missing payment details" }, 400);
  if (!/^\d{12}$/.test(utr)) return json({ error: "Enter the 12-digit UTR / reference number from your GPay receipt." }, 400);

  const row = await env.DB.prepare(
    "SELECT token_hash, status, utr_attempts FROM manual_payments WHERE id = ?"
  ).bind(b.paymentId).first<{ token_hash: string; status: string; utr_attempts: number }>();

  if (!row || row.token_hash !== (await sha256(b.token))) return json({ error: "Payment not found" }, 404);
  if (row.status === "approved") return json({ error: "Already verified" }, 409);
  if (row.status === "pending_verification") return json({ error: "Already submitted. Waiting for verification." }, 409);
  if (row.utr_attempts >= 5) return json({ error: "Too many attempts. Please contact support." }, 429);

  try {
    await env.DB.prepare(
      `UPDATE manual_payments
       SET utr = ?, status = 'pending_verification', utr_attempts = utr_attempts + 1,
           submitted_at = datetime('now'), reject_reason = NULL
       WHERE id = ?`
    ).bind(utr, b.paymentId).run();
  } catch (e) {
    if (!String(e).includes("UNIQUE")) return json({ error: "Could not save. Try again." }, 500);
    await env.DB.prepare("UPDATE manual_payments SET utr_attempts = utr_attempts + 1 WHERE id = ?").bind(b.paymentId).run();
    return json({ error: "This reference number was already used. Check it and try again, or contact support." }, 409);
  }
  return json({ status: "pending_verification" });
};
