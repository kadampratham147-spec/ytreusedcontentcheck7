import { Env, json, sha256 } from "../../_lib/payments";

// GET /api/payments/status?id=...   Header: x-payment-token
export const onRequestGet: PagesFunction<Env> = async ({ request, env }) => {
  const id = new URL(request.url).searchParams.get("id") ?? "";
  const token = request.headers.get("x-payment-token") ?? "";
  const row = await env.DB.prepare(
    "SELECT token_hash, status, reject_reason FROM manual_payments WHERE id = ?"
  ).bind(id).first<{ token_hash: string; status: string; reject_reason: string | null }>();
  if (!row || row.token_hash !== (await sha256(token))) return json({ error: "Not found" }, 404);
  return json({ status: row.status, rejectReason: row.reject_reason });
};
