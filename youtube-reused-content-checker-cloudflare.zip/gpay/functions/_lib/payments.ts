export interface Env {
  DB: D1Database;
  ADMIN_TOKEN: string; // secret: `wrangler pages secret put ADMIN_TOKEN`
}

export const PRICE_INR = 49; // amount is fixed server-side; the client never sets it

/** Parse a JSON body safely; returns {} on bad input so callers validate fields. */
export async function readJson<T>(request: Request): Promise<Partial<T>> {
  try { return (await request.json()) as Partial<T>; } catch { return {}; }
}

export const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });

export async function sha256(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** Admin check: Authorization: Bearer <ADMIN_TOKEN>. Fails closed if the secret is unset. */
export function isAdmin(request: Request, env: Env): boolean {
  if (!env.ADMIN_TOKEN || env.ADMIN_TOKEN.length < 24) return false;
  const header = request.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  return safeEqual(token, env.ADMIN_TOKEN);
}

/**
 * Call this at the top of your EXISTING "start channel scan" endpoint.
 * The scan may start only when an admin has approved the payment.
 */
export async function assertPaymentApproved(env: Env, paymentId: string, scanRef: string) {
  const row = await env.DB.prepare(
    "SELECT status, scan_ref FROM manual_payments WHERE id = ?"
  ).bind(paymentId).first<{ status: string; scan_ref: string }>();
  if (!row || row.status !== "approved" || row.scan_ref !== scanRef) {
    throw new Response(JSON.stringify({ error: "Payment not verified" }), {
      status: 402,
      headers: { "content-type": "application/json" },
    });
  }
}
