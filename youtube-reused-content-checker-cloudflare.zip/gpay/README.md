# YouTube Reused Content Checker: Cloudflare deployment

Stack: Vite + React + TypeScript + Tailwind (frontend), Cloudflare Pages Functions (backend, in `functions/`), Cloudflare D1 (database).

## What works, and what does not
Implemented (code written, NOT yet tested end to end):
- GPay QR payment page with "I've Paid", UTR entry, Pending Verification status
- Admin dashboard at `/admin/payments` (approve / reject, token-protected)
- Server-side gate that blocks the scan until a payment is approved

NOT implemented in this project: the free video checker, YouTube Data API calls, the risk-scoring engine and the channel scan itself. `functions/api/scan/start.ts` checks payment, then returns 501. Do not tell customers scanning works until you add and test those parts.

## Deploy step by step
1. Install Node 20 from nodejs.org and create free accounts on GitHub and Cloudflare.
2. In this folder run: `npm install`, then `npm run build`. If the build fails, send me the error.
3. Create the database: `npx wrangler login`, then `npx wrangler d1 create reused-content-checker`. Copy the `database_id` it prints into `wrangler.toml`.
4. Create the tables: `npm run db:remote`
5. Push the project to a new GitHub repository (`.gitignore` already keeps secrets out).
6. Cloudflare dashboard -> Workers & Pages -> Create -> Pages -> Connect to Git. Pick the repository and use:
   - Framework preset: None (or Vite)
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Environment variable `NODE_VERSION` = `20`
7. After the first deploy: Settings -> Variables and Secrets -> add secret `ADMIN_TOKEN` (random, 24+ characters; a password manager can generate it). Redeploy.
8. Confirm the D1 binding named `DB` shows under Settings -> Bindings (it comes from `wrangler.toml`).
9. Protect the admin area: Zero Trust -> Access -> add an application for `yourdomain/admin/*` and `yourdomain/api/admin/*` (free for up to 50 users).
10. Optional: add a Cloudflare rate-limiting rule on `/api/payments/*`.

## Environment variables
| Name | Where | Required |
|---|---|---|
| `ADMIN_TOKEN` | Pages secret (and `.dev.vars` locally) | Yes. Admin API refuses all requests without it |
| `NODE_VERSION` | Pages build variable | Recommended: `20` |
| `YOUTUBE_API_KEY` | Pages secret | Only when you add the YouTube features |
| `DB` | D1 binding via `wrangler.toml` | Yes |

## Test after deploying (do all of these before taking payments)
- `/`, `/scan`, `/admin/payments` load, and a page refresh on each still works
- `/gpay-qr.png` opens and is your QR; compare it with the original on your phone
- Open `/scan`, continue, tap "I've Paid", enter a 12-digit test number: status shows Pending
- `/admin/payments` rejects a wrong token, shows the entry with the right token, Approve works once
- `/api/scan/start` returns 402 before approval, and a 501 "not implemented" message after
- A real ₹49 test payment from your own phone, matched to its UTR before you approve

## Local run
`cp .dev.vars.example .dev.vars`, set `ADMIN_TOKEN`, run `npm run db:local`, then `npm run build && npm run preview`.

## Security notes
Amount is fixed server-side. A UTR can be used once. Buyer tokens are stored hashed. Admin endpoints fail closed if `ADMIN_TOKEN` is unset. Always match the exact amount and UTR in your GPay/bank history before approving. Update your Terms and Refund Policy to say payment is verified manually.
