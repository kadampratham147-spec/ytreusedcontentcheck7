import { useState } from "react";

interface Payment {
  id: string; scan_ref: string; amount_inr: number; status: string;
  utr: string | null; submitted_at: string | null;
}

// Route this at /admin/payments. Also protect /admin/* and /api/admin/* with Cloudflare Access.
export default function AdminPayments() {
  // Token is kept in memory only (not localStorage), so closing the tab signs you out.
  const [token, setToken] = useState("");
  const [authed, setAuthed] = useState(false);
  const [rows, setRows] = useState<Payment[]>([]);
  const [msg, setMsg] = useState("");

  const headers = () => ({ authorization: `Bearer ${token}`, "content-type": "application/json" });

  async function load() {
    const r = await fetch("/api/admin/payments?status=pending_verification", { headers: headers() });
    if (!r.ok) { setAuthed(false); return setMsg("Wrong admin token."); }
    setRows((await r.json()).payments);
    setAuthed(true);
    setMsg("");
  }

  async function decide(id: string, action: "approve" | "reject") {
    const reason = action === "reject" ? prompt("Reason shown to the customer (optional)") ?? "" : undefined;
    const r = await fetch("/api/admin/payments", {
      method: "POST", headers: headers(), body: JSON.stringify({ id, action, reason }),
    });
    setMsg(r.ok ? (action === "approve" ? "Approved." : "Rejected.") : (await r.json()).error);
    load();
  }

  if (!authed) {
    return (
      <main className="mx-auto max-w-sm p-6 text-white">
        <h1 className="text-xl font-semibold">Payment verification</h1>
        <input type="password" value={token} onChange={(e) => setToken(e.target.value)}
          placeholder="Admin token" aria-label="Admin token"
          className="mt-4 w-full rounded-lg border border-white/20 bg-[#1f1f1f] p-3" />
        <button onClick={load} className="mt-3 w-full rounded-full bg-[#ff0033] py-3 font-semibold">Sign in</button>
        {msg && <p role="alert" className="mt-3 text-sm text-[#ff6680]">{msg}</p>}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-3xl p-6 text-white">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Pending payments ({rows.length})</h1>
        <button onClick={load} className="rounded-full border border-white/20 px-4 py-1 text-sm">Refresh</button>
      </div>
      <p className="mt-2 text-sm text-[#aaaaaa]">
        Approve only after the exact ₹49 credit and its UTR appear in your GPay / bank history.
      </p>
      {msg && <p role="status" className="mt-2 text-sm">{msg}</p>}
      {rows.length === 0 && <p className="mt-8 text-[#aaaaaa]">Nothing waiting for verification.</p>}
      <ul className="mt-4 space-y-3">
        {rows.map((p) => (
          <li key={p.id} className="rounded-xl border border-white/10 bg-[#1f1f1f] p-4">
            <p className="font-mono text-lg">UTR {p.utr}</p>
            <p className="text-sm text-[#aaaaaa]">₹{p.amount_inr} · scan {p.scan_ref} · submitted {p.submitted_at}</p>
            <div className="mt-3 flex gap-2">
              <button onClick={() => decide(p.id, "approve")} className="rounded-full bg-green-600 px-4 py-2 text-sm font-semibold">Approve</button>
              <button onClick={() => decide(p.id, "reject")} className="rounded-full border border-[#ff0033] px-4 py-2 text-sm">Reject</button>
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
