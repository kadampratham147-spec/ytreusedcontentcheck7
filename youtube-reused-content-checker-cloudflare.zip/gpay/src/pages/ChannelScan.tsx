import { useState } from "react";
import GPayPayment from "../components/GPayPayment";

// PLACEHOLDER: connect this to your real channel validation (Stage A).
// Payment must only be shown after validation succeeds and returns a scan id.
export default function ChannelScan() {
  const [scanRef, setScanRef] = useState<string | null>(null);
  const [msg, setMsg] = useState("");

  async function startScan(paymentId: string) {
    const r = await fetch("/api/scan/start", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ paymentId, scanRef }),
    });
    setMsg((await r.json()).message ?? "Scan request sent.");
  }

  return (
    <main className="p-6">
      {!scanRef ? (
        <div className="mx-auto max-w-md">
          <p className="text-sm text-[#aaaaaa]">Placeholder: channel validation is not connected in this starter.</p>
          <button onClick={() => setScanRef("demo-scan-1")}
            className="mt-3 rounded-full border border-white/20 px-4 py-2 text-sm">
            Continue with a test scan id
          </button>
        </div>
      ) : (
        <GPayPayment scanRef={scanRef} onApproved={startScan} />
      )}
      {msg && <p className="mt-4 text-center text-sm">{msg}</p>}
    </main>
  );
}
