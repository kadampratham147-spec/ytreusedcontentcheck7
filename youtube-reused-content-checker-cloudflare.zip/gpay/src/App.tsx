import { Link, Route, Routes } from "react-router-dom";
import ChannelScan from "./pages/ChannelScan";
import AdminPayments from "./pages/AdminPayments";

// STARTER SHELL: replace Home and add your existing pages/routes here.
function Home() {
  return (
    <main className="mx-auto max-w-2xl p-8">
      <h1 className="text-2xl font-bold">YouTube Reused Content Checker</h1>
      <p className="mt-2 text-[#aaaaaa]">Starter shell. Add your existing pages here.</p>
      <Link to="/scan" className="mt-6 inline-block rounded-full bg-[#ff0033] px-5 py-3 font-semibold">
        Scan Full Channel — ₹49
      </Link>
    </main>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/scan" element={<ChannelScan />} />
      <Route path="/admin/payments" element={<AdminPayments />} />
    </Routes>
  );
}
