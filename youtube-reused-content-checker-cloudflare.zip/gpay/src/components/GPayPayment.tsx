import { useEffect, useState } from "react";

type Status = "awaiting_payment" | "pending_verification" | "approved" | "rejected";

interface Props {
  scanRef: string;               // id of the validated channel scan
  onApproved: (paymentId: string) => void; // start the scan only here
}

export default function GPayPayment({ scanRef, onApproved }: Props) {
  const [pay, setPay] = useState<{ paymentId: string; token: string } | null>(null);
  const [status, setStatus] = useState<Status>("awaiting_payment");
  const [showUtr, setShowUtr] = useState(false);
  const [utr, setUtr] = useState("");
  const [error, setError] = useState("");
  const [reason, setReason] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Create the payment record once, when the payment screen opens.
  useEffect(() => {
    fetch("/api/payments/create", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ scanRef }),
    })
      .then((r) => r.json())
      .then((d) => (d.paymentId ? setPay(d) : setError(d.error ?? "Could not start payment.")))
      .catch(() => setError("Could not reach the server. Try again."));
  }, [scanRef]);

  // Poll while waiting for the admin to verify.
  useEffect(() => {
    if (!pay || status !== "pending_verification") return;
    const t = setInterval(async () => {
      const r = await fetch(`/api/payments/status?id=${pay.paymentId}`, {
        headers: { "x-payment-token": pay.token },
      });
      if (!r.ok) return;
      const d = await r.json();
      setStatus(d.status);
      setReason(d.rejectReason);
      if (d.status === "approved") onApproved(pay.paymentId);
    }, 8000);
    return () => clearInterval(t);
  }, [pay, status, onApproved]);

  async function submitUtr() {
    if (!pay) return;
    setBusy(true);
    setError("");
    const r = await fetch("/api/payments/submit-utr", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ paymentId: pay.paymentId, token: pay.token, utr }),
    });
    const d = await r.json();
    setBusy(false);
    if (!r.ok) return setError(d.error ?? "Something went wrong.");
    setStatus("pending_verification");
  }

  return (
    <section className="mx-auto max-w-md rounded-2xl border border-white/10 bg-[#1f1f1f] p-6 text-white">
      <h2 className="text-xl font-semibold">Full Channel Reused Content Scan</h2>
      <p className="mt-1 text-3xl font-bold">₹49 <span className="text-sm font-normal text-[#aaaaaa]">one-time, this scan only</span></p>

      {(status === "awaiting_payment" || status === "rejected") && (
        <>
          {status === "rejected" && (
            <p role="alert" className="mt-4 rounded-lg border border-[#ff0033]/40 bg-[#ff0033]/10 p-3 text-sm">
              We couldn't match your payment{reason ? `: ${reason}` : ""}. Check the reference number and submit it again, or contact support.
            </p>
          )}
          <ol className="mt-4 list-decimal space-y-1 pl-5 text-sm text-[#aaaaaa]">
            <li>Open Google Pay or any UPI app and scan this code.</li>
            <li>Pay exactly ₹49.</li>
            <li>Come back and tap “I’ve Paid”.</li>
          </ol>
          <img
            src="/gpay-qr.png"
            alt="Google Pay QR code for the ₹49 payment"
            className="mx-auto mt-4 w-64 max-w-full rounded-xl bg-white"
          />
          {!showUtr ? (
            <button
              disabled={!pay}
              onClick={() => setShowUtr(true)}
              className="mt-5 w-full rounded-full bg-[#ff0033] py-3 font-semibold transition hover:brightness-110 disabled:opacity-50"
            >
              I’ve Paid
            </button>
          ) : (
            <div className="mt-5">
              <label htmlFor="utr" className="text-sm font-medium">UPI transaction reference (UTR)</label>
              <input
                id="utr"
                inputMode="numeric"
                maxLength={12}
                value={utr}
                onChange={(e) => setUtr(e.target.value.replace(/\D/g, ""))}
                placeholder="12-digit number from your GPay receipt"
                className="mt-1 w-full rounded-lg border border-white/20 bg-[#0f0f0f] p-3 outline-none focus:border-[#ff0033]"
              />
              <p className="mt-2 text-xs text-[#aaaaaa]">
                Never share your UPI PIN or OTP. We only need the reference number.
              </p>
              <button
                disabled={busy || utr.length !== 12}
                onClick={submitUtr}
                className="mt-3 w-full rounded-full bg-[#ff0033] py-3 font-semibold transition hover:brightness-110 disabled:opacity-50"
              >
                {busy ? "Submitting…" : "Submit for verification"}
              </button>
            </div>
          )}
        </>
      )}

      {status === "pending_verification" && (
        <div className="mt-5 rounded-lg border border-yellow-500/40 bg-yellow-500/10 p-4 text-sm" role="status">
          <p className="font-semibold">Pending verification</p>
          <p className="mt-1 text-[#aaaaaa]">
            Your scan starts after we confirm the payment in our account. This is done manually, so it may take some time. You can keep this page open.
          </p>
        </div>
      )}

      {status === "approved" && (
        <p className="mt-5 rounded-lg border border-green-500/40 bg-green-500/10 p-4 text-sm" role="status">
          Payment verified. Starting your scan.
        </p>
      )}

      {error && <p role="alert" className="mt-3 text-sm text-[#ff6680]">{error}</p>}
    </section>
  );
}
